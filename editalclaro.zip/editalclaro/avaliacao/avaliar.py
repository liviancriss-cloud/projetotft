"""Avalia a qualidade da busca com perguntas de teste.

O arquivo avaliacao/perguntas.csv tem duas colunas:
    pergunta,pagina_esperada
Deixe `pagina_esperada` vazia para perguntas cuja resposta NÃO está no edital
(servem para calibrar o limite mínimo de similaridade).

Uso:
    python avaliacao/avaliar.py
    python avaliacao/avaliar.py --csv avaliacao/perguntas.csv
"""

import argparse
import csv
import sys
from pathlib import Path

# Permite rodar como "python avaliacao/avaliar.py" a partir da raiz do projeto.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.busca import recuperar  # noqa: E402
from src.config import LIMITE_SIMILARIDADE  # noqa: E402

CSV_PADRAO = Path(__file__).resolve().parent / "perguntas.csv"
NIVEIS_K = (1, 3, 5)


def ler_perguntas(caminho: Path) -> list[tuple[str, int | None]]:
    perguntas = []
    with open(caminho, encoding="utf-8-sig", newline="") as arquivo:
        for linha in csv.DictReader(arquivo):
            texto = (linha.get("pergunta") or "").strip()
            if not texto:
                continue
            pagina = (linha.get("pagina_esperada") or "").strip()
            perguntas.append((texto, int(pagina) if pagina.isdigit() else None))
    return perguntas


def main() -> None:
    analisador = argparse.ArgumentParser(description="Avalia a busca do EditalClaro.")
    analisador.add_argument("--csv", type=Path, default=CSV_PADRAO)
    args = analisador.parse_args()

    perguntas = ler_perguntas(args.csv)
    if not perguntas:
        sys.exit(f"Nenhuma pergunta em {args.csv}. Preencha o arquivo (pergunta,pagina_esperada).")

    acertos = {k: 0 for k in NIVEIS_K}
    scores_corretos: list[float] = []  # similaridade do trecho certo (perguntas com resposta)
    scores_sem_resposta: list[float] = []  # melhor similaridade (perguntas sem resposta)
    com_resposta = 0
    passam_no_limite = 0

    print(f"{'ok':<4}{'melhor':<8}pergunta")
    for pergunta, pagina in perguntas:
        resultados = recuperar(pergunta, max(NIVEIS_K))
        melhor = resultados[0].score if resultados else 0.0

        if pagina is None:
            scores_sem_resposta.append(melhor)
            print(f"{'—':<4}{melhor:<8.2f}{pergunta}  (sem resposta no edital)")
            continue

        com_resposta += 1
        paginas_top = [t.pagina for t in resultados]
        for k in NIVEIS_K:
            if pagina in paginas_top[:k]:
                acertos[k] += 1
        correto = [t.score for t in resultados if t.pagina == pagina]
        if correto:
            scores_corretos.append(max(correto))
        if melhor >= LIMITE_SIMILARIDADE:
            passam_no_limite += 1
        marca = "✓" if pagina in paginas_top else "✗"
        print(f"{marca:<4}{melhor:<8.2f}{pergunta}  (esperada: p. {pagina})")

    print("\n=== Resultado ===")
    if com_resposta:
        for k in NIVEIS_K:
            print(f"Página correta entre os {k} primeiros trechos: {acertos[k]}/{com_resposta} "
                  f"({acertos[k] / com_resposta:.0%})")
        print(f"Perguntas que passam no limite atual ({LIMITE_SIMILARIDADE:.2f}): "
              f"{passam_no_limite}/{com_resposta}")
    if scores_sem_resposta:
        rejeitadas = sum(s < LIMITE_SIMILARIDADE for s in scores_sem_resposta)
        print(f"Perguntas sem resposta rejeitadas pelo limite: {rejeitadas}/{len(scores_sem_resposta)}")

    if scores_corretos and scores_sem_resposta:
        menor_correto, maior_negativo = min(scores_corretos), max(scores_sem_resposta)
        print(f"\nMenor similaridade de um acerto: {menor_correto:.2f} | "
              f"maior similaridade de pergunta sem resposta: {maior_negativo:.2f}")
        if maior_negativo < menor_correto:
            print(f"Sugestão: LIMITE_SIMILARIDADE entre {maior_negativo:.2f} e {menor_correto:.2f}")
        else:
            print("Os valores se sobrepõem: nenhum limite separa os dois grupos com perfeição.")


if __name__ == "__main__":
    main()
