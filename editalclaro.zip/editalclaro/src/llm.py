"""Acesso à API do Gemini: embeddings e geração de JSON."""

import json
import re
import time
from functools import lru_cache

import numpy as np

from src.config import (
    EMBEDDING_DIM,
    EMBEDDING_MODEL,
    GOOGLE_API_KEY,
    LLM_MODEL,
)

LOTE_EMBEDDINGS = 50
_ERROS_TRANSITORIOS = ("429", "500", "503", "RESOURCE_EXHAUSTED", "UNAVAILABLE", "DEADLINE")


@lru_cache(maxsize=1)
def cliente():
    """Cria (uma única vez) o cliente da API."""
    if not GOOGLE_API_KEY:
        raise RuntimeError(
            "GOOGLE_API_KEY não encontrada. Crie o arquivo .env a partir do .env.example."
        )
    from google import genai

    return genai.Client(api_key=GOOGLE_API_KEY)


def _com_tentativas(funcao, tentativas: int = 5):
    """Repete a chamada com espera crescente em erros temporários (limite de uso, indisponibilidade)."""
    for i in range(tentativas):
        try:
            return funcao()
        except Exception as erro:  # noqa: BLE001 - o SDK levanta vários tipos de erro
            temporario = any(c in str(erro) for c in _ERROS_TRANSITORIOS)
            if not temporario or i == tentativas - 1:
                raise
            time.sleep(2**i)


def normalizar(matriz: np.ndarray) -> np.ndarray:
    """Normaliza cada vetor para norma 1 (produto interno = similaridade de cosseno)."""
    normas = np.linalg.norm(matriz, axis=1, keepdims=True)
    return (matriz / np.clip(normas, 1e-12, None)).astype("float32")


def gerar_embeddings(textos: list[str], tarefa: str) -> np.ndarray:
    """Converte textos em vetores normalizados.

    tarefa: "RETRIEVAL_DOCUMENT" para trechos do edital e "RETRIEVAL_QUERY" para perguntas.
    """
    from google.genai import types

    vetores: list[list[float]] = []
    for i in range(0, len(textos), LOTE_EMBEDDINGS):
        lote = textos[i : i + LOTE_EMBEDDINGS]
        resposta = _com_tentativas(
            lambda lote=lote: cliente().models.embed_content(
                model=EMBEDDING_MODEL,
                contents=lote,
                config=types.EmbedContentConfig(
                    task_type=tarefa, output_dimensionality=EMBEDDING_DIM
                ),
            )
        )
        vetores.extend(e.values for e in resposta.embeddings)
    return normalizar(np.array(vetores, dtype="float32"))


def _extrair_json(texto: str):
    """Converte a saída do modelo em objeto Python, tolerando texto ao redor do JSON."""
    try:
        return json.loads(texto)
    except json.JSONDecodeError:
        achado = re.search(r"(\{.*\}|\[.*\])", texto, re.DOTALL)
        if not achado:
            raise ValueError("O modelo não devolveu um JSON válido.")
        return json.loads(achado.group(1))


def gerar_json(prompt: str, instrucao_sistema: str | None = None):
    """Chama o LLM pedindo saída em JSON e devolve o objeto já convertido."""
    from google.genai import types

    resposta = _com_tentativas(
        lambda: cliente().models.generate_content(
            model=LLM_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=instrucao_sistema,
                temperature=0.1,
                response_mime_type="application/json",
            ),
        )
    )
    if not resposta.text:
        raise RuntimeError("O modelo não retornou conteúdo (resposta vazia ou bloqueada).")
    return _extrair_json(resposta.text)
