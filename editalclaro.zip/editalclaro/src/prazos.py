"""Extração de prazos do edital e exportação para calendário (.ics)."""

import hashlib
import json
import re
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from src.config import ICS_PATH, PAGINAS_PATH, PRAZOS_PATH
from src.llm import gerar_json
from src.prompts import PROMPT_PRAZOS, SISTEMA_PRAZOS

MAX_CARACTERES_LOTE = 12000
MAX_PAGINAS_LOTE = 4

_MESES = "janeiro|fevereiro|março|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro"
# Páginas sem nenhuma data nem precisam ser enviadas ao modelo.
_TEM_DATA = re.compile(
    rf"\b\d{{1,2}}\s*/\s*\d{{1,2}}(?:\s*/\s*\d{{2,4}})?\b"
    rf"|\b\d{{1,2}}\.\d{{1,2}}\.\d{{4}}\b"
    rf"|\b\d{{1,2}}\s*(?:º|°)?\s+de\s+(?:{_MESES})\b",
    re.IGNORECASE,
)


@dataclass
class Prazo:
    evento: str
    data: str  # AAAA-MM-DD
    pagina: int
    data_fim: str | None = None  # AAAA-MM-DD (quando for um período)
    horario: str | None = None
    trecho: str = ""

    @classmethod
    def de_dict(cls, dados: dict, paginas_validas: set[int] | None = None) -> "Prazo | None":
        """Valida um item devolvido pelo modelo. Devolve None se estiver inconsistente."""
        try:
            evento = str(dados["evento"]).strip()
            inicio = date.fromisoformat(str(dados["data"]).strip())
            pagina = int(dados["pagina"])
            fim_bruto = dados.get("data_fim")
            fim = None
            if fim_bruto and str(fim_bruto).strip().lower() not in ("null", "none"):
                fim = date.fromisoformat(str(fim_bruto).strip())
        except (KeyError, ValueError, TypeError):
            return None

        if not evento:
            return None
        if paginas_validas is not None and pagina not in paginas_validas:
            return None
        if fim is not None and fim < inicio:
            fim = None

        horario = dados.get("horario")
        horario = str(horario).strip() if horario and str(horario).lower() != "null" else None
        return cls(
            evento=evento,
            data=inicio.isoformat(),
            pagina=pagina,
            data_fim=fim.isoformat() if fim else None,
            horario=horario,
            trecho=str(dados.get("trecho") or "").strip()[:200],
        )


# --- Formatação -------------------------------------------------------------
def formatar_data(iso: str) -> str:
    return date.fromisoformat(iso).strftime("%d/%m/%Y")


def formatar_periodo(prazo: Prazo) -> str:
    texto = formatar_data(prazo.data)
    if prazo.data_fim and prazo.data_fim != prazo.data:
        texto += f" a {formatar_data(prazo.data_fim)}"
    if prazo.horario:
        texto += f" ({prazo.horario})"
    return texto


# --- Extração ---------------------------------------------------------------
def paginas_com_datas(paginas: list[dict]) -> list[dict]:
    return [p for p in paginas if _TEM_DATA.search(p["texto"])]


def criar_lotes(
    paginas: list[dict],
    max_caracteres: int = MAX_CARACTERES_LOTE,
    max_paginas: int = MAX_PAGINAS_LOTE,
) -> list[list[dict]]:
    """Agrupa páginas em lotes pequenos para caber com folga no contexto do modelo."""
    lotes: list[list[dict]] = []
    atual: list[dict] = []
    caracteres = 0
    for pagina in paginas:
        tamanho = len(pagina["texto"])
        if atual and (len(atual) >= max_paginas or caracteres + tamanho > max_caracteres):
            lotes.append(atual)
            atual, caracteres = [], 0
        atual.append(pagina)
        caracteres += tamanho
    if atual:
        lotes.append(atual)
    return lotes


def _deduplicar(prazos: list[Prazo]) -> list[Prazo]:
    vistos = set()
    unicos = []
    for prazo in prazos:
        chave = (re.sub(r"\W+", "", prazo.evento.lower()), prazo.data, prazo.data_fim)
        if chave not in vistos:
            vistos.add(chave)
            unicos.append(prazo)
    return sorted(unicos, key=lambda p: (p.data, p.pagina))


def carregar_prazos() -> list[Prazo] | None:
    """Lê os prazos já extraídos (cache em disco). None se ainda não foram extraídos."""
    if not PRAZOS_PATH.exists():
        return None
    return [Prazo(**item) for item in json.loads(PRAZOS_PATH.read_text(encoding="utf-8"))]


def extrair_prazos(forcar: bool = False) -> list[Prazo]:
    """Extrai os prazos do edital processado. Usa o cache, a menos que `forcar=True`."""
    if not forcar:
        em_cache = carregar_prazos()
        if em_cache is not None:
            return em_cache

    if not PAGINAS_PATH.exists():
        raise FileNotFoundError(
            "Nenhum edital foi processado ainda. Rode: python src/ingestao.py data/editais/seu_edital.pdf"
        )

    paginas = json.loads(PAGINAS_PATH.read_text(encoding="utf-8"))
    encontrados: list[Prazo] = []
    for lote in criar_lotes(paginas_com_datas(paginas)):
        validas = {p["pagina"] for p in lote}
        texto = "\n\n".join(f"[Página {p['pagina']}]\n{p['texto']}" for p in lote)
        try:
            dados = gerar_json(PROMPT_PRAZOS.format(paginas=texto), SISTEMA_PRAZOS)
        except Exception as erro:  # não guarda resultado parcial: prazo faltando é perigoso
            raise RuntimeError(
                f"Falha ao extrair prazos das páginas {min(validas)} a {max(validas)}: {erro}"
            ) from erro

        itens = dados.get("prazos", []) if isinstance(dados, dict) else dados
        for item in itens if isinstance(itens, list) else []:
            if isinstance(item, dict):
                prazo = Prazo.de_dict(item, validas)
                if prazo:
                    encontrados.append(prazo)

    prazos = _deduplicar(encontrados)
    PRAZOS_PATH.parent.mkdir(parents=True, exist_ok=True)
    PRAZOS_PATH.write_text(
        json.dumps([asdict(p) for p in prazos], ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return prazos


# --- Exportação .ics (RFC 5545) ----------------------------------------------
def _escapar(texto: str) -> str:
    return (
        texto.replace("\\", "\\\\")
        .replace(";", "\\;")
        .replace(",", "\\,")
        .replace("\r", "")
        .replace("\n", "\\n")
    )


def _dobrar(linha: str) -> str:
    """Quebra linhas com mais de 75 bytes, como exige o formato, sem cortar caracteres."""
    dados = linha.encode("utf-8")
    partes = []
    limite = 75
    while len(dados) > limite:
        corte = limite
        while corte > 0 and (dados[corte] & 0xC0) == 0x80:  # não corta no meio de um caractere
            corte -= 1
        partes.append(dados[:corte].decode("utf-8"))
        dados = dados[corte:]
        limite = 74  # as linhas seguintes começam com um espaço
    partes.append(dados.decode("utf-8"))
    return "\r\n ".join(partes)


def gerar_ics(prazos: list[Prazo], caminho: Path = ICS_PATH) -> Path | None:
    """Grava os prazos como eventos de dia inteiro. Devolve o caminho, ou None se não há prazos."""
    if not prazos:
        return None

    agora = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    linhas = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//EditalClaro//PT-BR//",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
    ]
    for prazo in prazos:
        inicio = date.fromisoformat(prazo.data)
        fim = date.fromisoformat(prazo.data_fim) if prazo.data_fim else inicio
        descricao = f"Fonte: edital, p. {prazo.pagina}."
        if prazo.horario:
            descricao += f" Horário: {prazo.horario}."
        descricao += " Confirme no edital oficial."
        chave = f"{prazo.evento}|{prazo.data}|{prazo.data_fim}"
        uid = hashlib.sha1(chave.encode("utf-8")).hexdigest()[:20] + "@editalclaro"
        linhas += [
            "BEGIN:VEVENT",
            f"UID:{uid}",
            f"DTSTAMP:{agora}",
            f"DTSTART;VALUE=DATE:{inicio:%Y%m%d}",
            f"DTEND;VALUE=DATE:{fim + timedelta(days=1):%Y%m%d}",  # fim é exclusivo
            f"SUMMARY:{_escapar(prazo.evento)}",
            f"DESCRIPTION:{_escapar(descricao)}",
            "END:VEVENT",
        ]
    linhas.append("END:VCALENDAR")

    caminho.parent.mkdir(parents=True, exist_ok=True)
    with open(caminho, "w", encoding="utf-8", newline="") as arquivo:
        arquivo.write("\r\n".join(_dobrar(linha) for linha in linhas) + "\r\n")
    return caminho
