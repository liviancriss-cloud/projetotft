"""Busca dos trechos mais parecidos com a pergunta, com limite mínimo de similaridade."""

import json
from dataclasses import dataclass
from functools import lru_cache

from src.config import (
    INDEX_PATH,
    LIMITE_SIMILARIDADE,
    META_PATH,
    TOP_K,
    TRECHOS_PATH,
)


@dataclass
class Trecho:
    id: int
    pagina: int
    texto: str
    arquivo: str
    score: float = 0.0


def indice_disponivel() -> bool:
    return INDEX_PATH.exists() and TRECHOS_PATH.exists()


def info_edital() -> dict | None:
    """Metadados do edital processado (nome do arquivo, nº de páginas e de trechos)."""
    if not META_PATH.exists():
        return None
    return json.loads(META_PATH.read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def _carregar(data_modificacao: float):
    """Carrega índice e trechos. A chave de cache muda quando o índice é refeito."""
    import faiss

    indice = faiss.read_index(str(INDEX_PATH))
    trechos = json.loads(TRECHOS_PATH.read_text(encoding="utf-8"))
    return indice, trechos


def recuperar(pergunta: str, k: int = TOP_K) -> list[Trecho]:
    """Devolve os k trechos mais parecidos, com a similaridade, SEM aplicar o limite mínimo."""
    from src.llm import gerar_embeddings

    if not indice_disponivel():
        raise FileNotFoundError(
            "Nenhum edital foi processado ainda. Rode: python src/ingestao.py data/editais/seu_edital.pdf"
        )

    indice, trechos = _carregar(INDEX_PATH.stat().st_mtime)
    consulta = gerar_embeddings([pergunta], "RETRIEVAL_QUERY")
    scores, posicoes = indice.search(consulta, min(k, indice.ntotal))

    resultado = []
    for score, posicao in zip(scores[0], posicoes[0]):
        if posicao < 0:
            continue
        dados = trechos[posicao]
        resultado.append(
            Trecho(
                id=dados["id"],
                pagina=dados["pagina"],
                texto=dados["texto"],
                arquivo=dados["arquivo"],
                score=float(score),
            )
        )
    return resultado


def buscar(pergunta: str, k: int = TOP_K, limite: float = LIMITE_SIMILARIDADE) -> list[Trecho]:
    """Como `recuperar`, mas descarta trechos abaixo do limite. Lista vazia = sem evidência."""
    return [t for t in recuperar(pergunta, k) if t.score >= limite]
