"""Configurações centrais do EditalClaro (caminhos, modelos e parâmetros)."""

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

# --- Caminhos ---------------------------------------------------------------
DATA_DIR = BASE_DIR / "data"
EDITAIS_DIR = DATA_DIR / "editais"
INDEX_DIR = DATA_DIR / "index"
EXPORTS_DIR = DATA_DIR / "exports"

INDEX_PATH = INDEX_DIR / "index.faiss"
TRECHOS_PATH = INDEX_DIR / "trechos.json"
PAGINAS_PATH = INDEX_DIR / "paginas.json"
META_PATH = INDEX_DIR / "meta.json"
PRAZOS_PATH = INDEX_DIR / "prazos.json"
ICS_PATH = EXPORTS_DIR / "prazos.ics"

# --- Modelos ----------------------------------------------------------------
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "")
LLM_MODEL = os.getenv("GEMINI_MODEL", "gemini-flash-latest")
EMBEDDING_MODEL = "gemini-embedding-001"
EMBEDDING_DIM = 768

# --- Busca ------------------------------------------------------------------
TOP_K = int(os.getenv("TOP_K", "5"))
# Similaridade mínima (cosseno) para considerar que há evidência no edital.
# Calibre com: python avaliacao/avaliar.py
LIMITE_SIMILARIDADE = float(os.getenv("LIMITE_SIMILARIDADE", "0.5"))

# --- Divisão em trechos -----------------------------------------------------
TAMANHO_TRECHO = 900
SOBREPOSICAO = 150

# --- Servidor ---------------------------------------------------------------
PORT = int(os.getenv("PORT", "7860"))
