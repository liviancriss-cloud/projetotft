"""Ingestão do edital: PDF -> páginas -> trechos -> embeddings -> índice vetorial.

Uso:
    python src/ingestao.py data/editais/meu_edital.pdf
"""

import argparse
import json
import re
import sys
from pathlib import Path

# Permite rodar como "python src/ingestao.py" a partir da raiz do projeto.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.config import (  # noqa: E402
    EMBEDDING_DIM,
    EMBEDDING_MODEL,
    INDEX_DIR,
    INDEX_PATH,
    META_PATH,
    PAGINAS_PATH,
    PRAZOS_PATH,
    SOBREPOSICAO,
    TAMANHO_TRECHO,
    TRECHOS_PATH,
)

_FIM_DE_FRASE = re.compile(r"(?<=[.!?;:])\s+")


def limpar_texto(texto: str) -> str:
    """Junta palavras hifenizadas na quebra de linha e normaliza espaços."""
    texto = re.sub(r"-\n(?=[a-zà-ú])", "", texto)
    return re.sub(r"\s+", " ", texto).strip()


def extrair_paginas(caminho_pdf: Path) -> list[dict]:
    """Lê o PDF e devolve [{"pagina": 1, "texto": "..."}], preservando o número da página."""
    import fitz  # PyMuPDF

    paginas = []
    with fitz.open(caminho_pdf) as documento:
        for numero, pagina in enumerate(documento, start=1):
            paginas.append({"pagina": numero, "texto": limpar_texto(pagina.get_text("text"))})
    return paginas


def dividir_texto(
    texto: str, tamanho: int = TAMANHO_TRECHO, sobreposicao: int = SOBREPOSICAO
) -> list[str]:
    """Divide o texto em trechos de até ~`tamanho` caracteres, respeitando o fim das frases.

    Os trechos consecutivos compartilham até `sobreposicao` caracteres para não perder contexto.
    """
    partes: list[str] = []
    for frase in filter(None, _FIM_DE_FRASE.split(texto)):
        while len(frase) > tamanho:  # frase gigante: corta à força
            partes.append(frase[:tamanho])
            frase = frase[tamanho:]
        partes.append(frase)

    trechos: list[str] = []
    atual: list[str] = []
    tamanho_atual = 0
    for parte in partes:
        if atual and tamanho_atual + len(parte) + 1 > tamanho:
            trechos.append(" ".join(atual))
            cauda: list[str] = []
            soma = 0
            for anterior in reversed(atual):
                if soma + len(anterior) > sobreposicao:
                    break
                cauda.insert(0, anterior)
                soma += len(anterior) + 1
            atual = cauda
            tamanho_atual = sum(len(x) + 1 for x in atual)
        atual.append(parte)
        tamanho_atual += len(parte) + 1
    if atual:
        trechos.append(" ".join(atual))

    return [t for t in trechos if len(t) >= 30]


def criar_trechos(paginas: list[dict], arquivo: str, tamanho: int, sobreposicao: int) -> list[dict]:
    """Cria a lista de trechos, cada um com a página de origem."""
    trechos = []
    for pagina in paginas:
        for texto in dividir_texto(pagina["texto"], tamanho, sobreposicao):
            trechos.append(
                {"id": len(trechos), "pagina": pagina["pagina"], "texto": texto, "arquivo": arquivo}
            )
    return trechos


def salvar_indice(trechos: list[dict], paginas: list[dict], arquivo: str) -> None:
    """Gera os embeddings e grava índice, trechos, páginas e metadados em data/index/."""
    import faiss

    from src.llm import gerar_embeddings

    vetores = gerar_embeddings([t["texto"] for t in trechos], "RETRIEVAL_DOCUMENT")
    indice = faiss.IndexFlatIP(vetores.shape[1])
    indice.add(vetores)

    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    faiss.write_index(indice, str(INDEX_PATH))
    TRECHOS_PATH.write_text(json.dumps(trechos, ensure_ascii=False), encoding="utf-8")
    PAGINAS_PATH.write_text(json.dumps(paginas, ensure_ascii=False), encoding="utf-8")
    META_PATH.write_text(
        json.dumps(
            {
                "arquivo": arquivo,
                "paginas": len(paginas),
                "trechos": len(trechos),
                "modelo_embeddings": EMBEDDING_MODEL,
                "dimensao": EMBEDDING_DIM,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    # Os prazos em cache pertenciam ao edital anterior.
    PRAZOS_PATH.unlink(missing_ok=True)


def main() -> None:
    analisador = argparse.ArgumentParser(description="Processa um edital em PDF e cria o índice.")
    analisador.add_argument("pdf", type=Path, help="caminho do PDF do edital")
    analisador.add_argument("--tamanho", type=int, default=TAMANHO_TRECHO, help="tamanho do trecho")
    analisador.add_argument("--sobreposicao", type=int, default=SOBREPOSICAO, help="sobreposição")
    args = analisador.parse_args()

    if not args.pdf.exists():
        sys.exit(f"Arquivo não encontrado: {args.pdf}")

    print(f"Lendo {args.pdf.name} ...")
    paginas = extrair_paginas(args.pdf)
    sem_texto = [p["pagina"] for p in paginas if len(p["texto"]) < 30]
    if len(sem_texto) == len(paginas):
        sys.exit(
            "Nenhum texto extraído. O PDF parece ser escaneado (imagem); "
            "aplique OCR antes de processar."
        )
    if sem_texto:
        print(f"Aviso: {len(sem_texto)} página(s) sem texto (podem ser imagens): {sem_texto[:15]}")

    trechos = criar_trechos(paginas, args.pdf.name, args.tamanho, args.sobreposicao)
    print(f"{len(paginas)} páginas -> {len(trechos)} trechos. Gerando embeddings ...")
    salvar_indice(trechos, paginas, args.pdf.name)
    print(f"Pronto! Índice salvo em {INDEX_DIR}")


if __name__ == "__main__":
    main()
