"""Monta o contexto, consulta o LLM e devolve a resposta com as páginas citadas."""

from dataclasses import dataclass, field

from src.busca import Trecho, buscar
from src.llm import gerar_json
from src.prompts import PROMPT_RESPOSTA, SISTEMA_RESPOSTA

MSG_NAO_ENCONTRADO = "Não encontrei essa informação no edital."
TAMANHO_CITACAO = 240


@dataclass
class Resposta:
    encontrou: bool
    texto: str
    paginas: list[int] = field(default_factory=list)
    trechos: list[Trecho] = field(default_factory=list)

    def formatar(self) -> str:
        """Texto final para o chat: resposta, páginas e trechos consultados."""
        if not self.encontrou:
            return self.texto

        partes = [self.texto, f"**Fonte:** {_listar_paginas(self.paginas)}"]
        citacoes = []
        for pagina in self.paginas:
            da_pagina = [t for t in self.trechos if t.pagina == pagina]
            if da_pagina:
                melhor = max(da_pagina, key=lambda t: t.score)
                citacoes.append(f"> **p. {pagina}:** {_resumir(melhor.texto)}")
        if citacoes:
            partes.append("**Trechos consultados:**\n\n" + "\n>\n".join(citacoes))
        return "\n\n".join(partes)


def _listar_paginas(paginas: list[int]) -> str:
    rotulos = [f"p. {p}" for p in paginas]
    if len(rotulos) <= 1:
        return "".join(rotulos)
    return ", ".join(rotulos[:-1]) + " e " + rotulos[-1]


def _resumir(texto: str) -> str:
    return texto if len(texto) <= TAMANHO_CITACAO else texto[:TAMANHO_CITACAO].rstrip() + "…"


def _montar_contexto(trechos: list[Trecho]) -> str:
    ordenados = sorted(trechos, key=lambda t: (t.pagina, t.id))
    return "\n\n".join(f"[Página {t.pagina}]\n{t.texto}" for t in ordenados)


def responder(pergunta: str) -> Resposta:
    """Responde à pergunta usando apenas o que o edital diz."""
    pergunta = pergunta.strip()
    if not pergunta:
        raise ValueError("Digite uma pergunta.")

    trechos = buscar(pergunta)
    if not trechos:  # nada parecido o bastante: nem chama o LLM
        return Resposta(encontrou=False, texto=MSG_NAO_ENCONTRADO)

    dados = gerar_json(
        PROMPT_RESPOSTA.format(contexto=_montar_contexto(trechos), pergunta=pergunta),
        SISTEMA_RESPOSTA,
    )
    if not isinstance(dados, dict):
        raise RuntimeError("O modelo devolveu uma resposta em formato inesperado. Tente novamente.")

    texto = str(dados.get("resposta") or "").strip()
    if not dados.get("encontrado") or not texto:
        return Resposta(encontrou=False, texto=MSG_NAO_ENCONTRADO)

    disponiveis = {t.pagina for t in trechos}
    citadas = sorted(
        {int(p) for p in dados.get("paginas") or [] if str(p).isdigit() and int(p) in disponiveis}
    )
    if not citadas:  # o modelo não indicou páginas válidas: cita as páginas consultadas
        citadas = sorted(disponiveis)

    return Resposta(encontrou=True, texto=texto, paginas=citadas, trechos=trechos)
